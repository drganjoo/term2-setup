#ifndef UWS_UWS_H
#define UWS_UWS_H

#pragma warning(push)
#pragma warning(disable: 4251)
#pragma warning(disable: 4800)
#pragma warning(disable: 4996)
#pragma warning(disable: 4018)
#include "Hub.h"
#pragma warning(pop)
#endif // UWS_UWS_H
